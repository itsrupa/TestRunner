/**
 * Module dependencies.
 */

var express = require('express');
var http = require('http');
var path = require('path');
var moment = require('moment');
var fs = require('fs');


require('shelljs/global');

var app = express();

var server = require('http').createServer(app)
var io = require('socket.io').listen(server);



app.configure(function() {
  app.use(express.favicon());
  app.use(express.logger('dev'));
  app.use(express.json()); // to support JSON-encoded bodies
  app.use(express.urlencoded()); // to support URL-encoded bodies
  app.use(express.static(path.join(__dirname, 'public')));
});

app.post('/startTest', function(req, res) {
  res.send("");
  startTest(req.body.releaseName, req.body.moduleName);
});

app.get('/allResults', function(req, res) {
  var allResultsFolder = __dirname + '/public/results';
  fs.readdir(allResultsFolder, function(err, files) {
    if (err) {
      console.log(err);
      res.json({
        error: 'could not read results folder'
      });
    }
    console.log(files);
    res.json(files);
  });
});

var socket;
io.sockets.on('connection', function(soc) {
  socket = soc;

});

//global result file
var resultFile;


function createResultsFile(releaseName, moduleName) {
  releaseName = releaseName.replace("/", "_");
  resultFile = __dirname + '/public/results/' + releaseName + "__" + moduleName + "__" + moment().format("MM-DD-YYYY-hhmmssA") + ".html";
  console.log("ResultFile Name:" + resultFile);
}

function logAndStreamData(data) {
  //send it back to browser immediately
  socket.emit('TestRunnerChannel', data);

  //write to result file as html <p> with different colors
  var className = "text-success";
  if (data.indexOf("Error") >= 0) {
    className = "text-danger";
  }
  if (data.indexOf('Running Test For:') == 0) {
    className = 'bg-primary customPadding';
  }
  echo('<p class="' + className + '">' + data + '</p>').toEnd(resultFile);
}

function startTest(releaseName, moduleName) {
  createResultsFile("release/2012323", "customer-portal");

  logAndStreamData("Running Test For: Release Name: " + releaseName + " Module Name: " + moduleName);
  var data = which('git');
  if (!data) {
    logAndStreamData('Sorry, this script requires git');
  }

  logAndStreamData('Doing... git commit -am "Auto-commit" ');
  var result = exec('git commit -am "Auto-commit"');
  if (result.code !== 0) {
    echo('Error: Git commit failed');
    console.dir(result.output);
    logAndStreamData('Error... ' + result.output);
    // exit(1);
  }

  setTimeout(function() {

    logAndStreamData("After 5 seconds");
  }, 5000);

  var result2 = exec('git commit -am "Auto-commit"');
  if (result2.code !== 0) {
    logAndStreamData('Error2: Git commit failed');
    logAndStreamData(result2.output);
    // exit(1);
  }
}

app.configure('development', function() {
  app.use(express.errorHandler());
});


server.listen(3000);